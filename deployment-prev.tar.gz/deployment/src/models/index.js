import Service from './serviceModel';
import Booking from './bookingModel';

export default {
  Service,
  Booking
};